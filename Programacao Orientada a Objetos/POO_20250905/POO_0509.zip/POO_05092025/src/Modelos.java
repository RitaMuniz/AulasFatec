public class Modelos {

    public double calcularBasico(double diarias) {
        return 90.00 * diarias;
    }

    public double calcularIntermediario(double diarias) {
        return 110.00 * diarias;
    }

    public double calcularLuxo(double diarias) {
        return 200.00 * diarias;
    }
}
