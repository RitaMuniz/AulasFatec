public class Cliente {

    private String nome;
    private String idade;
    private String nCNH;

    public Cliente(String nome, String idade, String nCNH) {
        this.nome = nome;
        this.idade = idade;
        this.nCNH = nCNH;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getIdade() {
        return idade;
    }

    public void setIdade(String idade) {
        this.idade = idade;
    }

    public String getnCNH() {
        return nCNH;
    }

    public void setnCNH(String nCNH) {
        this.nCNH = nCNH;
    }
}
