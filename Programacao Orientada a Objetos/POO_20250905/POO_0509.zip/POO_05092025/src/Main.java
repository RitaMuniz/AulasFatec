/*
crie um programa em java que o aluguel de carros.
O cliente deverá entrar com nome, idade, numero da CNH, modelo desejado e numero de diarias.
A locadora tem 3 modelos disponiveis: basico, intermediario, e luxo.
sendo que a tarifa do básico é de 90 reais a diaria, o intermediario é de 110 reais a diaria e o luxo 200 reais a diaria.
O programa deverá calcular o valor total da diaria e exibir todos os dados do cliente na tela
 */

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        String nome;
        String idade;
        String ncnh;
        int modelo;
        int diarias;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Programa de Aluguel de Carros");

        System.out.println("Digite seu nome: ");
        nome = scanner.nextLine();

        System.out.println("Digite sua idade: ");
        idade = scanner.nextLine();

        System.out.println("Digite o numero da sua CNH: ");
        ncnh = scanner.nextLine();

        do {
            System.out.println("""
                    Escolha um dos modelos de carros:
                    Modelo basico (R$90/d): Digite 1
                    Modelo intermediario(R$110/d): Digite 2
                    Modelo luxo(R$200/d): Digite 3
                    
                    Qual modelo gostaria? """);
            modelo = scanner.nextInt();
        } while (modelo > 3 || modelo < 1);

        do {
            System.out.println("Por quantos dias pretende alugar o veiculo? ");
            diarias = scanner.nextInt();
        } while (diarias > 3 || diarias < 1);

        Cliente c = new Cliente(nome, idade, ncnh);

        System.out.printf("""
                Olá %s
                Idade: %s
                Numero da CNH: %s
                """, c.getNome(), c.getIdade(), c.getnCNH());

        Modelos m = new Modelos();
        switch (modelo) {
            case 1:
                System.out.printf("""
                        Dados do aluguel:
                        Modelo escolhido: Basico
                        Diárias: %d dias
                        Valor Total: R$%.2f
                        """, diarias, m.calcularBasico(diarias));
                break;
            case 2:
                System.out.printf("""
                        Dados do aluguel:
                        Modelo escolhido: Intermediario
                        Diárias: %d dias
                        Valor Total: R$%.2f
                        """, diarias, m.calcularIntermediario(diarias));
                break;
            case 3:
                System.out.printf("""
                        Dados do aluguel:
                        Modelo escolhido: Luxo
                        Diárias: %d dias
                        Valor Total: R$%.2f
                        """, diarias, m.calcularLuxo(diarias));
                break;
            default:
                System.out.println("Erro");
        }
    }
}