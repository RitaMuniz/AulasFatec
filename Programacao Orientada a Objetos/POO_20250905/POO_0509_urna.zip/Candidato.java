public class Candidato {
    private String nome;
    private int votos;

    public Candidato(String nome) {
        this.nome = nome;
        this.votos = 0;
    }

    public void adicionarVoto() {
        this.votos += 1;
    }

    public int getVotos(){
        return votos;
    }

    public String getNome() {
        return this.nome;
    }
}
