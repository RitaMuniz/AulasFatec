// Dupla Rita de Cássia & Felipe Cavalcante

public class Main {
    public static void main(String[] args) {

        Urna eleicao = new Urna();

        eleicao.simularVotacao();

        eleicao.exibirResultados();

    }
}
