import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Urna {

    private List<Candidato> vereador;
    private List<Candidato> prefeito;
    private List<Eleitor> eleitores = new ArrayList<>();

    private int qtdEleitores;
    private int abstencoes;
    private int votosEmBranco;

    public Urna() {
        vereador = new ArrayList<>();
        vereador.add(new Candidato("Luis Inicio Bolsonaro da Silva"));
        vereador.add(new Candidato("BolsoLula"));
        vereador.add(new Candidato("Rainha Elisabeth"));
        vereador.add(new Candidato("Silvio Santos"));
        vereador.add(new Candidato("Gusttavo Lima"));
        vereador.add(new Candidato("Felipe Neto"));
        vereador.add(new Candidato("Tim Maia"));
        vereador.add(new Candidato("Luis Inicio Bolsonaro da Silva"));
        vereador.add(new Candidato("BolsoLula"));
        vereador.add(new Candidato("Rainha Elisabeth"));
        vereador.add(new Candidato("Silvio Santos"));
        vereador.add(new Candidato("Gusttavo Lima"));
        vereador.add(new Candidato("Felipe Neto"));
        vereador.add(new Candidato("Tim Maia"));
        vereador.add(new Candidato("Luis Inicio Bolsonaro da Silva"));
        vereador.add(new Candidato("BolsoLula"));
        vereador.add(new Candidato("Rainha Elisabeth"));
        vereador.add(new Candidato("Silvio Santos"));
        vereador.add(new Candidato("Gusttavo Lima"));
        vereador.add(new Candidato("Felipe Neto"));
        vereador.add(new Candidato("Tim Maia"));
        vereador.add(new Candidato("Luis Inicio Bolsonaro da Silva"));
        vereador.add(new Candidato("BolsoLula"));
        vereador.add(new Candidato("Rainha Elisabeth"));
        vereador.add(new Candidato("Silvio Santos"));

        prefeito = new ArrayList<>();
        prefeito.add(new Candidato("Luis Inicio Bolsonaro da Silva"));
        prefeito.add(new Candidato("BolsoLula"));
        prefeito.add(new Candidato("Rainha Elisabeth"));
        prefeito.add(new Candidato("Silvio Santos"));
    }

    public void simularVotacao() {
        Random random = new Random();
        qtdEleitores = random.nextInt(100, 10000);
        abstencoes = random.nextInt(50, 5000);
        if (abstencoes > qtdEleitores) { abstencoes = qtdEleitores; }

        for (int i=0; i<qtdEleitores-abstencoes; i++) {
            eleitores.add(new Eleitor(
                    prefeito.get(random.nextInt(0, 4)),
                    vereador.get(random.nextInt(0, 25))));
        }


        System.out.println("Iniciando simulação");

        for (Eleitor e : eleitores) {
            if (e.prefeito != null) {
                if (random.nextInt(0, 10) < 9) {
                    e.prefeito.adicionarVoto();
                }
                else {
                    e.prefeito = null;
                    votosEmBranco += 1;
                }
            }

            if (e.vereador != null) {
                if (random.nextInt(0, 10) < 9) {
                    e.vereador.adicionarVoto();
                }
                else {
                    e.vereador = null;
                    votosEmBranco += 1;
                }
            }
        }

        System.out.println("Simulação Concluída!");
    }

    public void exibirResultados() {
        System.out.println("Resultado");
        System.out.println("Total eleitores: " + qtdEleitores);

        System.out.println("\nVereadores: ");
        for (Candidato vereador : vereador) {
            System.out.println(vereador.getNome() + ": " + vereador.getVotos() + " votos");
        }

        System.out.println("\nPrefeito: ");
        for (Candidato prefeito : prefeito) {
            System.out.println(prefeito.getNome() + ": " + prefeito.getVotos() + " votos");
        }

        int totalVotosContados = 0;
        for (Candidato candidato : vereador) {
            totalVotosContados += candidato.getVotos();
        }
        totalVotosContados += this.votosEmBranco;

        System.out.println("\nVotos ausentes: " + this.abstencoes);
        System.out.println("Votos em branco: " + this.votosEmBranco);
        System.out.println("Votos contabilizados: " + totalVotosContados);
    }



}
