public class Eleitor {
    public Candidato prefeito;
    public Candidato vereador;

    public Eleitor(Candidato prefeito, Candidato vereador) {
        this.prefeito = prefeito;
        this.vereador = vereador;
    }

    public Candidato getPrefeito() {
        return prefeito;
    }

    public Candidato getVereador() {
        return vereador;
    }
}
